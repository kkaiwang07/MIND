# MIND
Python implemenation of Manifold Inference from Neural Dynamics (MIND) from the paper

Low, R. J., Lewallen, S., Aronov, D., Nevers, R., & Tank, D. W. (2018). Probing variability in a cognitive map using manifold inference from neural dynamics. bioRxiv, 418939.
https://www.biorxiv.org/content/10.1101/418939v2
